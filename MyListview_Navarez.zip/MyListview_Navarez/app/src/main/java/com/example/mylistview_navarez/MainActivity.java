package com.example.mylistview_navarez;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;


import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView listview;
    ArrayList<String> list = new ArrayList<String>();
    ArrayAdapter<String> adapter;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list.add("Alpha");
        list.add("Bravo");
        list.add("Charlie");
        list.add("Delta");
        list.add("Echo");
        list.add("Foxtrot");
        list.add("Gulf");
        list.add("Hotel");
        listview = findViewById(R.id.listView);
        adapter = new ArrayAdapter<String>(this, R.layout.item_layout, R.id.textView, list);
        listview.setAdapter(adapter);
        builder = new AlertDialog.Builder(this);
        listview.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        String selected_item = list.get(i);
        //Toast.makeText(this, selected_item, Toast.LENGTH_SHORT).show();
        builder.setMessage(selected_item);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}