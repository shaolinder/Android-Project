package com.example.act2_navarez;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText idnum, name;
    RadioGroup gender;
    RadioButton radioButton;
    Button okbtn, canbtn;
    Spinner myspinner;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idnum = (EditText) findViewById(R.id.id_no);
        name = (EditText) findViewById(R.id.name);

        myspinner = (Spinner) findViewById(R.id.spinner);

        gender = (RadioGroup) findViewById(R.id.group_radio);
        gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int selectedButton = gender.getCheckedRadioButtonId();
                radioButton = (RadioButton) findViewById(selectedButton);

            }
        });

        builder = new AlertDialog.Builder(this);



        okbtn = (Button) findViewById(R.id.button_ok);
        okbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (idnum.getText().toString().length() != 0 && name.getText().toString().length() != 0 && gender.getCheckedRadioButtonId() != -1) {
                    builder.setTitle("Student Information");
                    builder.setMessage("idno :" + idnum.getText().toString() +
                            "\nname: " + name.getText().toString() +
                            "\ncourse: " + myspinner.getSelectedItem().toString() + "\ngender: " + radioButton.getText().toString());

                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();
                                }
                            })
                            .show();
                }
                else {
                    Toast.makeText(MainActivity.this, "FILL ALL FIELDS", Toast.LENGTH_SHORT).show();
                }
            }
        });

        canbtn = (Button) findViewById(R.id.button_cancel);
        canbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}