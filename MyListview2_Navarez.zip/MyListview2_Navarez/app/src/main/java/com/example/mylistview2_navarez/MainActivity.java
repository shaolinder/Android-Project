package com.example.mylistview2_navarez;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    itemAdapter adapter;

    ArrayList<Person> list = new ArrayList<Person>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list.add(new Person(R.drawable.pic1, "Anabelle", "a@gmail.com"));
        list.add(new Person(R.drawable.pic2, "John", "j@gmail.com"));
        list.add(new Person(R.drawable.pic3, "Erick", "e@gmail.com"));
        list.add(new Person(R.drawable.pic4, "Anton", "an@gmail.com"));
        list.add(new Person(R.drawable.pic5, "Jessica", "j@gmail.com"));
        list.add(new Person(R.drawable.pic6, "Anne", "anne@gmail.com"));


        lv = findViewById(R.id.listview);
        adapter = new itemAdapter(this, list);
        lv.setAdapter(adapter);

    }
}