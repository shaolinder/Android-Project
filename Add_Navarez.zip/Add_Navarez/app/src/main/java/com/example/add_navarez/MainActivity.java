package com.example.add_navarez;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Menu;
import android.widget.AdapterView;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.view.View;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    //List<String> list = new ArrayList<String>();
    //ArrayAdapter<String> adapter;
    itemAdapter adapter;
    ArrayList<Person> list = new ArrayList<Person>();;
    String name, fname;
    Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = findViewById(R.id.listView);
        //adapter = new ArrayAdapter<String>(this, R.layout.itemlayout,R.id.textView2,list);
        adapter = new itemAdapter(this, list);
        lv.setAdapter(adapter);
        this.setTitle("Activity Menu");

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Display a dialog box when an item is clicked
                showItemDialog(position);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//       int option = item.getItemId();
//       if (option == R.id.additem){
            Intent intent = new Intent(this, AddItem.class);
            //this.startActivity(intent);
            this.startActivityForResult(intent,0);
//       }
        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
//            if (requestCode==0) {
//                name = data.getStringExtra("name");
//                list.add(name);
//                adapter.notifyDataSetChanged();
//            }
            if (requestCode==0) {
                Bundle b = data.getExtras();
                imageUri = b.getParcelable("image");
                name = b.getString("name");
                fname = b.getString("fname");
                list.add(new Person(imageUri, name, fname));
                adapter.notifyDataSetChanged();
            }
        }
    }
    private void showItemDialog(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(name + ", " + fname).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}