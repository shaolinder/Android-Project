package com.example.add_navarez;

import android.net.Uri;

public class Person {
    private Uri image;
    private String name, fname;

    public Person(Uri image, String name, String fname) {
        this.image = image;
        this.name = name;
        this.fname = fname;
    }
    public String getFname() {
        return fname;
    }
    public void setFname(String fname) {
        this.fname = fname;
    }
    public Uri getImage() {
        return image;
    }
    public void setImage(Uri image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
