package com.example.add_navarez;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class AddItem extends AppCompatActivity implements View.OnClickListener {

    EditText txtName, txtfname;
    Button btnSave, btnCancel;
    ImageView iv;
    Uri imageUri;
    String name, fname;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        txtName = findViewById(R.id.name);
        txtfname = findViewById(R.id.fname);
        btnSave = findViewById(R.id.button);
        btnCancel = findViewById(R.id.button2);
        iv = findViewById(R.id.imageView2);
        this.btnSave.setOnClickListener(this);
        this.btnCancel.setOnClickListener(this);
        this.iv.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
//        int id = view.getId();
//        if(view.getId()==R.id.imageView){
//            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//            startActivityForResult(intent,100);
//        }
//    }
        int id = view.getId();
        Intent intent = null;
        if(id==R.id.imageView2){
            intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent,100);
        }
        else if (id==R.id.button){
            name = txtName.getText().toString();
            fname = txtfname.getText().toString();
            if(imageUri != null && !name.equals("")&& !fname.equals("")) {
                //blind intent
                intent = new Intent();
                intent.putExtra("name", name);
                intent.putExtra("fname", fname);
                intent.putExtra("image", imageUri);
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
//            else
//                Toast.makeText(this.option, Toast.LENGTH_SHORT).show();
        }
        else
            finish();
//        switch (id){
//            case 2131230819:
//                String name = this.txtName.getText().toString();
//                //blind intent
//                Intent intent=new Intent();
//                intent.putExtra("name",name);
//                this.setResult(Activity.RESULT_OK,intent);
//            case 2131230820:
//                finish();
//        }
//        System.out.println(id);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK){
            if (requestCode == 100){
                imageUri = data.getData();
                iv.setImageURI(imageUri);
            }
        }
    }
}
