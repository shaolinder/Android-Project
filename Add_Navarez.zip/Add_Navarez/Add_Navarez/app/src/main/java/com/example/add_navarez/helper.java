package com.example.add_navarez;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class helper extends SQLiteOpenHelper {
    static String DB = "person_DB";

    static String PERSON = "tbl_person";

    public helper(Context context) {
        super(context, DB, null, 1);

    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE "+ PERSON + "(id INTEGER PRIMARY KEY AUTOINCREMENT,imageuri varchar(50), name varchar(50),email varchar(50))");
    }

    public long addPerson(Person p){
        long result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("imageuri",p.getImage().toString());
        cv.put("name",p.getName().toString());
        cv.put("email",p.getFname().toString());
        result=db.insert(PERSON,null,cv);
        db.close();
        return result;
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
