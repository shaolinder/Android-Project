package com.example.mylocation;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ItemHolder> {

    private final RecycleViewInterface recycleViewInterface;
    Context context;
    ArrayList<Coordinates> list;

    public MyAdapter(Context context, ArrayList<Coordinates> list,RecycleViewInterface recycleViewInterface) {
        this.context = context;
        this.list = list;
        this.recycleViewInterface = recycleViewInterface;
    }

    @NonNull
    @Override
    public MyAdapter.ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_layout,parent,false);

        return new ItemHolder(view, recycleViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ItemHolder holder, int position) {
        holder.latitude.setText(list.get(position).getLatitude());
        holder.longitude.setText(list.get(position).getLongitude());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ItemHolder extends RecyclerView.ViewHolder{
        TextView latitude, longitude;

        public ItemHolder(@NonNull View itemView, RecycleViewInterface recycleViewInterface) {
            super(itemView);

            latitude = itemView.findViewById(R.id.itemLat);
            longitude = itemView.findViewById(R.id.itemLong);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recycleViewInterface != null){
                        int position = getAdapterPosition();

                        if (position != RecyclerView.NO_POSITION){
                            recycleViewInterface.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
