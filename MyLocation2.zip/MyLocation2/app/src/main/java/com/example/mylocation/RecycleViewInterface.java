package com.example.mylocation;

public interface RecycleViewInterface {
    void onItemClick(int position);
}
