package com.example.horoscope_navarez;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
public class itemAdapter extends BaseAdapter {
    Context context;

    ArrayList<Horoscope> list;
    ArrayList<Horoscope> filteredList;

    LayoutInflater inflater;

    public itemAdapter(Context context, ArrayList<Horoscope> list) {
        this.context = context;
        this.list = list;
        this.inflater = LayoutInflater.from(context);
        this.filteredList = new ArrayList<>(list);
    }

    @Override
    public int getCount() {
        return filteredList.size();
    }

    @Override
    public Object getItem(int i) {
        return filteredList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ItemHolder holder = null;
        if(view == null) {
            view = inflater.inflate(R.layout.itemlayout, null);
            holder = new ItemHolder();
            holder.iv = view.findViewById(R.id.imageView);
            holder.name = view.findViewById(R.id.textView);
            holder.date = view.findViewById(R.id.textView2);
            view.setTag(holder);
        }
        else
            holder = (ItemHolder) view.getTag();
        holder.iv.setImageResource(filteredList.get(i).getImage());
        holder.name.setText(filteredList.get(i).getName());
        holder.date.setText(filteredList.get(i).getDate());

        return view;
    }
    static class ItemHolder{

        ImageView iv;
        TextView name;
        TextView date;

    }
    public void updateList(ArrayList<Horoscope> newList) {
        filteredList.clear();
        filteredList.addAll(newList);
        notifyDataSetChanged();
    }
}

