package com.example.horoscope_navarez;

public class Horoscope {
    private int image;
    private String name, date, message;
    public Horoscope(int image, String name, String date, String message){
            this.image = image;
            this.name = name;
            this.date = date;
            this.message = message;
    }
    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String email) {
        this.date = email;
    }
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
}
