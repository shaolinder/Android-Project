package com.example.horoscope_navarez;

import static com.example.horoscope_navarez.R.layout.itemlayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    itemAdapter adapter;
    ArrayList<Horoscope> list = new ArrayList<>();
    ArrayList<Horoscope> filteredList = new ArrayList<>();
    EditText txtSearch;
    AlertDialog.Builder builder;
    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list.add(new Horoscope(R.drawable.aquarius, "Aquarius", "January 20 - February 18","Symbol: The Water-bearer\n" +
                "Element: Air" + "Ruler:  Saturn, the taskmaster\n\n" + "Aquarius, the quirky Zodiac, is forward-thinking, innovative, and deeply concerned with the collective. "
                +"They are intellectual, offbeat, progressive, independent, and idealistic, often residing on the fringes of society with a unique vision of the world."));
        list.add(new Horoscope(R.drawable.pisces, "Pisces", "February 19 - March 20","Symbol: The Fish\n" +
                "Element: Water" + "Ruler:  Jupiter, Planet of faith\n\n" + "Pisces symbolizes the gestation period and is deeply mystical, connected to ethers, big dreams, "
                +"and emotions. They are empathetic, generous, and creative, but need to be cautious of giving too much. They are friendly, sensitive, kind, and caring."));
        list.add(new Horoscope(R.drawable.aries, "Aries", "March 21 - April 19","Symbol: The Ram\n" +
                "Element: Fire" + "Ruler: Mars, God of action, war, & passion\n\n" + "Aries, the first of the 6 inner-focused Signs, is a bold and life-path-carving individual who is direct, "
                +"passionate, and headstrong. They are confident, direct, and unafraid to demand what they want, standing tall in their opinions. "));
        list.add(new Horoscope(R.drawable.taurus, "Taurus", "April 20 - May 20","Symbol: The Bull\n" +
                "Element: Earth" + "Ruler: Venus, the Goddess of love and beauty\n\n" + "The earthy bull is a grounded sign, enjoying earthly pleasures like good food, quality fabrics, "
                +"and luxurious experiences. They appreciate balance and value for their investments. They are hard-working, determined, and practical. They are dedicated, dependable, and stubborn."));
        list.add(new Horoscope(R.drawable.gemini, "Gemini", "May 21 - June 20","Symbol: The Twins\n" +
                "Element: Air" + "Ruler:  Mercury, the messenger God\n\n" + "The flighty twins are quick-thinking, socialite butterflies, and adaptable. They are intellectual, constantly thinking, "
                +"and adaptable. They are chatty, amicable, and have a zesty personality, balancing entertainment and indecisiveness."));
        list.add(new Horoscope(R.drawable.cancer, "Cancer", "June 21 - July 22","Symbol: The Crab\n" +
                "Element: Water" + "Ruler:  The Moon, ruler of our emotions\n\n" + "Cancerians are nurturing, emotional Zodiacs with a strong sense of family and love. "
                +"They are in touch with emotions and may be moody. They care deeply about others, especially through food, and are loyal, protective, and intuitive."));
        list.add(new Horoscope(R.drawable.leo, "Leo", "July 23 - August 22","Symbol: The Lion\n" +
                "Element: Fire" + "Ruler:  The Sun, ruler of our core personality\n\n" + "Leo, the fiery center of our solar system, is a star of the show, a great performer, "
                +"generous server, and leader. They are confident, extravagant, loyal, and ambitious, spreading joy and happiness."));
        list.add(new Horoscope(R.drawable.virgo, "Virgo", "August 23 - September 22","Symbol: The Maiden\n" +
                "Element: Earth" + "Ruler:  Mercury, the God of Communication\n\n" + "The earthy analyst, a ruler of Mercury, is focused on critical analysis and perfectionism. "
                +"They are practical, grounded, sensible, flexible, and open to change. They believe they know best, but are discerning and may become single-minded or overly judgemental, aiming to help others."));
        list.add(new Horoscope(R.drawable.libra, "Libra", "September 23 - October 22","Symbol: The Scales\n" +
                "Element: Air" + "Ruler:  Venus, Goddess of love\n\n" + "Libra, ruled by the scales and Venus, is a romantic sign concerned with relationships. "
                +"They are diplomats, diplomats, and mediators, seeking balance and harmony. They are idealistic, imaginative, and may be indecisive."));
        list.add(new Horoscope(R.drawable.scorpio, "Scorpio", "October 23 - November 21","Symbol:  The Scorpion\n" +
                "Element: Water" + "Ruler:  Mars, Warrior Planet\n\n" + "Scorpio, the deepest and mysterious Zodiac sign, is intense, magnetic, and open to dark aspects of life. "
                +"It represents evolution and transformation, with symbols like snake and eagle. Scorpio is in touch with emotions, intuition, and mystical aspects, but may be secretive."));
        list.add(new Horoscope(R.drawable.sagittarius, "Sagittarius", "November 22 - December 21","Symbol: The Archer\n" +
                "Element: Fire" + "Ruler:  Jupiter, the Planet of fortune\n\n" + "Sagittarius, a Zodiac sign, is an expansive optimist who enjoys exploring the world and discussing various topics. "
                +"They are truth-seekers, often sarcastic, and have a positive outlook. They are spontaneous, passionate about freedom, and enjoy conversing with diverse individuals."));
        list.add(new Horoscope(R.drawable.capricorn, "Capricorn", "December 22 - January 19","Symbol: The Sea/Mountain Goat\n" +
                "Element: Earth" + "Ruler:  Saturn, the Planet of austerity\n\n" + "The mountain goat is a hardworking, determined, and ambitious individual with a strong work ethic. "
                +"Capricorns are mature, wise, and resilient, with a strong work ethic and a strong work ethic. They value tradition and may have a hidden spiritual side."));

        lv = findViewById(R.id.listview);
        adapter = new itemAdapter(this, list);
        lv.setAdapter(adapter);
        builder = new AlertDialog.Builder(this);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick (AdapterView < ? > adapterView, View view,int i, long l){
                Horoscope select = list.get(i);
                String additional = select.getMessage();
                int resourceImg = select.getImage();
                showAlertDialog(select.getName(), select.getDate(), additional, resourceImg);
            }
        });
        txtSearch = findViewById(R.id.search);
        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String query = charSequence.toString().toLowerCase();
                filteredList.clear();

                for (Horoscope horoscope : list) {
                    if (horoscope.getName().toLowerCase().contains(query)) {
                        filteredList.add(horoscope);
                    }
                }

                adapter.updateList(filteredList);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }
    private void showAlertDialog(String title, String date, String additional, int resourceImg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String message = date + "\n\n" + additional;
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setIcon(resourceImg);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
